﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

Console.WriteLine("Mi segundo programa");
Console.WriteLine("Ingrese su nombre");
string nombre = Console.ReadLine();
Console.WriteLine("Ingrese su edad");
int edad = int.Parse(Console.ReadLine());
Console.WriteLine("Ingrese su carrera");
string carrera = Console.ReadLine();
Console.WriteLine("Ingrese su carnet");
int carnet = int.Parse(Console.ReadLine());

Console.WriteLine("Nombre: " + nombre);
Console.WriteLine("Edad: " + edad);
Console.WriteLine("Carrera: " + carrera);
Console.WriteLine("Carnet: " + carnet);
Console.WriteLine("Soy " + nombre + "tengo " + edad + "años y estudio la carrera de " + carrera + ". Mi nunmero de carnet es " + carnet);
Console.ReadKey();
