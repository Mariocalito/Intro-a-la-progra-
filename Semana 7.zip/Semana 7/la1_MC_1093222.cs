﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("LAB1");

Console.WriteLine("Hola Mundo soy Mario Calito");

Console.WriteLine("Hola Mundo");
Console.WriteLine("Soy Mario");

Console.Write("Hola Mundo");
Console.WriteLine();
Console.Write("Soy Calito");
Console.WriteLine();

//La diferencia principal entre Write y WriteLine es cómo manejan la impresión en la consola o en un archivo.
//Ambos métodos se utilizan para mostrar información,
//pero difieren en la forma en que tratan los saltos de línea:

Console.WriteLine("Ingrese su nombre");
string nombre = Console.ReadLine();

Console.WriteLine("Hola Mundo");
Console.WriteLine(" Soy " + nombre);

Console.Write("Hola Mundo");
Console.Write(" Soy " + nombre);
Console.ReadKey();
