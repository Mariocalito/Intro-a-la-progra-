﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ejercicio 1");

        Console.Write("Número ENTERO: ");
        string input = Console.ReadLine();

        if (int.TryParse(input, out int numero))
        {
            if (numero > 0)
            {
                Console.WriteLine("RESULTADO: El número es positivo.");
            }
            else if (numero < 0)
            {
                Console.WriteLine("RESULTADO: El número es negativo.");
            }
            else
            {
                Console.WriteLine("RESULTADO: El número es cero.");
            }
        }
        else
        {
            Console.WriteLine("Error: El valor ingresado no es un número entero.");
        }

        Console.ReadKey();
        Console.Clear();
        Console.WriteLine("Ejercicio 2");
        Console.WriteLine("Ingrese un numero del 1 al 7");
        int num = Convert.ToInt32(Console.ReadLine());
        string día = "";
        if (num == 1)
        {
            día = "Lunes";
        }
        else if (num == 2)
        {
            día = "Martes";
        }
        else if (num == 3)
        {
            día = "Miercoles";
        }
        else if (num == 4)
        {
            día = "Jueves";
        }
        else if (num == 5)
        {
            día = "Viernes";
        }
        else if (num == 6)
        {
            día = "Sabado";
        }
        else if (num == 7)
        {
            día = "Domingo";
        }
        else
        {
            Console.WriteLine("El numero ingresado no es valido");
        }
        Console.WriteLine("El numero " + num + " corresponde al dia " + día);

    }
}

