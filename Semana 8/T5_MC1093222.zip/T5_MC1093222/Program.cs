﻿double[] cantidad = new double[3];
string[] monedas = new string[3];
double tipoCambio = 7.83;

for (int i = 0; i < 3; i++)
{
    Console.Write("Ingrese la cantidad No. " + (i + 1) + ": ");
    double cant = Convert.ToDouble(Console.ReadLine());

    Console.Write("USD o GTQ: ");
    string moneda = Console.ReadLine();

    if (moneda.ToUpper() == "USD")
    {
        cantidad[i] = cant * tipoCambio;
        monedas[i] = "GTQ";
    }
    else if (moneda.ToUpper() == "GTQ")
    {
        cantidad[i] = cant;
        monedas[i] = "GTQ";
    }
    else
    {
        Console.WriteLine("Moneda no reconocida. Se asumirá GTQ por defecto.");
        cantidad[i] = cant;
        monedas[i] = "GTQ";
    }
}

Console.WriteLine("Resultado:");

for (int i = 0; i < 3; i++)
{
    Console.WriteLine(cantidad[i].ToString("") + " " + monedas[i]);
}

Console.ReadKey();
Console.Clear();    
Console.WriteLine("Tarea 2");

        double montoCompra;
        double descuento = 0.0;

        Console.WriteLine("Ingrese el monto de la compra:");

       
        if (double.TryParse(Console.ReadLine(), out montoCompra))
        {
            if (montoCompra < 400)
            {
                
                descuento = 0.0;
            }
            else if (montoCompra >= 400 && montoCompra <= 1000)
            {
                
                descuento = montoCompra * 0.07;
            }
            else if (montoCompra > 1000 && montoCompra <= 5000)
            {
                
                descuento = montoCompra * 0.10;
            }
            else if (montoCompra > 5000 && montoCompra <= 15000)
            {
                
                descuento = montoCompra * 0.15;
            }
            else
            {
                
                descuento = montoCompra * 0.25;
            }

            
            Console.WriteLine("¿Tiene un código de descuento? (S/N):");
            string tieneCodigo = Console.ReadLine();

            if (tieneCodigo.ToUpper() == "S")
            {
                descuento += montoCompra * 0.05;
            }

           
            double montoFinal = montoCompra - descuento;

            Console.WriteLine($"Monto a pagar final: Q{montoFinal:N2}");
        }
        else
        {
            Console.WriteLine("Error: Ingrese un monto válido.");
        }
    

