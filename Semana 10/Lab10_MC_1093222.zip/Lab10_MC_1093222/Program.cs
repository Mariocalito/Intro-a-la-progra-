﻿namespace Lab10_MC_1093222
{
    using System;

    class Circulo
    {
        private double radio;

        public Circulo(double radio)
        {
            this.radio = radio;
        }

        private double ObtenerPerimetro()
        {
            return 2 * Math.PI * radio;
        }

        private double ObtenerArea()
        {
            return Math.PI * radio * radio;
        }

        private double ObtenerVolumen()
        {
            
            return 0;
        }

        public void CalcularGeometria(ref double unPerimetro, ref double unArea, ref double unVolumen)
        {
            unPerimetro = ObtenerPerimetro();
            unArea = ObtenerArea();
            unVolumen = ObtenerVolumen();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese el radio del círculo:");
            double radio = double.Parse(Console.ReadLine());

            double perimetro = 0;
            double area = 0;
            double volumen = 0;

            Circulo objCirculo = new Circulo(radio);
            objCirculo.CalcularGeometria(ref perimetro, ref area, ref volumen);

            Console.WriteLine($"Perímetro: {perimetro}");
            Console.WriteLine($"Área: {area}");
            Console.WriteLine($"Volumen: {volumen}");

            Console.ReadLine();


            Console.Clear();
        }
            class TrianguloRectangulo
        {
            private double catetoA;
            private double anguloOpuestoA;

            public TrianguloRectangulo(double catetoA, double anguloOpuestoA)
            {
                this.catetoA = catetoA;
                this.anguloOpuestoA = anguloOpuestoA;
            }

            public double ObtenerCatetoA()
            {
                return catetoA;
            }

            public double ObtenerCatetoB()
            {
                double anguloRad = anguloOpuestoA * (Math.PI / 180); // Convierte el ángulo a radianes
                return catetoA / Math.Tan(anguloRad);
            }

            public double ObtenerHipotenusa()
            {
                return Math.Sqrt(catetoA * catetoA + ObtenerCatetoB() * ObtenerCatetoB());
            }

            public double ObtenerAnguloOpuestoA()
            {
                return anguloOpuestoA;
            }

            public double ObtenerAnguloOpuestoB()
            {
                return 90 - anguloOpuestoA; // Los ángulos opuestos deben sumar 90 grados
            }

            public double ObtenerArea()
            {
                return 0.5 * catetoA * ObtenerCatetoB();
            }
        }

    }

}
    


